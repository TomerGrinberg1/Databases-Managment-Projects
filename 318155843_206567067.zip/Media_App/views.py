import sys

from django.contrib import messages
from django.shortcuts import render
from django.db.models import Count


from . import models
from .models import Households, Programranks, Recordreturns, Recordorders, Programs
from django.db import connection

from datetime import datetime


def management(request):
    if request.method == 'POST' and request.POST:
        # order
        if 'orderSubmit' in request.POST:
            new_title = request.POST["O_title"]
            new_hID = request.POST["O_hID"]
            flag_O = True
            while flag_O:
                if not (models.Households.objects.filter(hid=new_hID).exists()):
                    messages.error(request, "Error: no such family recorded")
                    flag_O = False
                    break
                if not (models.Programs.objects.filter(title=new_title).exists()):
                    messages.error(request, "Error: no such title recorded ")
                    flag_O = False
                    break
                count = Recordorders.objects.filter(hid=new_hID).count()
                if count >= 3:
                    messages.error(request, "Error: family already ordered 3 titles")
                    flag_O = False
                    break
                if models.Recordorders.objects.filter(title=new_title).exists() \
                        and not (models.Recordorders.objects.filter(hid=new_hID).exists()):
                    messages.error(request, "Error: title already taken")
                    flag_O = False
                    break
                if models.Recordorders.objects.filter(hid=new_hID, title=new_title).exists():
                    messages.error(request, "Error: you already have this title, dummy♥ ")
                    flag_O = False
                    break
                if models.Recordreturns.objects.filter(title=new_title, hid=new_hID).exists():
                    messages.error(request, "Error: you've already seen this title, dummy♥ ")
                    flag_O = False
                    break
                if models.Households.objects.filter(hid=new_hID, childrennum__gt=0).exists():
                    if models.Programs.objects.filter(title=new_title, genre__in=['Reality', 'Adults Only']).exists():
                        messages.error(request, "Error: inappropriate title ")
                        flag_O = False
                    break
                break
            program = models.Programs.objects.filter(title=new_title).first()
            famID = models.Households.objects.filter(hid=new_hID).first()
            if flag_O:
                new_content = Recordorders(title=program, hid=famID)
                new_content.save()
        # return
        if 'returnSubmit' in request.POST:
            new_R_title = request.POST["R_title"]
            new_R_hID = request.POST["R_hID"]
            flag_R = True
            while flag_R:
                if not (models.Households.objects.filter(hid=new_R_hID).exists()):
                    messages.error(request, "Error: no such family recorded")
                    flag_R = False
                    break
                if not (models.Programs.objects.filter(title=new_R_title).exists()):
                    messages.error(request, "Error: no such title recorded")
                    flag_R = False
                    break
                if not (models.Recordorders.objects.filter(hid=new_R_hID, title=new_R_title).exists()):
                    messages.error(request, "Error: you don't have this title")
                    flag_R = False
                    break
                if models.Recordreturns.objects.filter(hid=new_R_hID, title=new_R_title).exists():
                    messages.error(request, "Error: request denied")
                    flag_R = False
                    break
                break
            program = models.Programs.objects.filter(title=new_R_title).first()
            famID = models.Households.objects.filter(hid=new_R_hID).first()
            if flag_R:
                to_delete = Recordorders(title=program, hid=famID)
                to_delete.delete()
                record_return, created = models.Recordreturns.objects.get_or_create(title=program, hid=famID)
                if not created:
                    messages.error(request, "Error: the record already exists")
                # new_content = Recordreturns(title=program, hid=famID)
                # new_content.save()

    with connection.cursor() as cursor:
        cursor.execute(
            """
      select top 3 T.hID , Rsum+Osum as TotalOrder
    from
     (select  R.hID, sumReturn Rsum,coalesce(sumOrder,0) Osum
    from
    (select hID, count(hID) sumReturn
    from RecordReturns
    group by hID) R
     left join
    (select hID, count(hID) sumOrder
    from RecordOrders
    group by hID) O on R.hID=O.hID) T
    order by TotalOrder desc, hID asc
    

            """)
        sql_res4 = dictfetchall(cursor)
    return render(request, 'add_content.html', {'sql_res4': sql_res4})


def query4(request):
    with connection.cursor() as cursor:
        cursor.execute(
            """
        select top 3 T.hID , Rsum+Osum as TotalOrder
from
 (select  R.hID, coalesce(sumReturn,0) Rsum,coalesce(sumOrder,0) Osum
from
(select hID, count(hID) sumReturn
from RecordReturns
group by hID) R
 left join
(select hID, count(hID) sumOrder
from RecordOrders
group by hID) O on R.hID=O.hID) T
order by hID asc
                    
        """)
        sql_res4 = dictfetchall(cursor)
    return render(request, 'add_content.html', {'sql_res4': sql_res4})


def dictfetchall(cursor):
    # Return all rows from a cursor as a dict
    columns = [col[0] for col in cursor.description]
    return [dict(zip(columns, row)) for row in cursor.fetchall()]


def index(request):
    return render(request, 'index.html')


def ranks(request):
    # titles = [item['title'] for item in MyModel.objects.values('title').distinct()]
    sql_res5=None
    families = [item['hid'] for item in models.Households.objects.values('hid').distinct()]
    titles = [item['title'] for item in models.Programs.objects.values('title').distinct()]
    input_num = sys.maxsize
    input_genre = None
    if request.method == 'POST' and request.POST:
        if 'rankSubmit' in request.POST:
            new_hID = request.POST["fam"]
            new_title = request.POST["title"]
            new_rank = request.POST["rank"]
            # program = Programs.objects.get(title=new_title)
            # famID = Households.objects.get(hid=new_hID)
            program = models.Programs.objects.filter(title=new_title).first()
            famID = models.Households.objects.filter(hid=new_hID).first()
            if models.Programranks.objects.filter(title=new_title, hid=new_hID).exists():
                models.Programranks.objects.filter(title=new_title, hid=new_hID).update(rank=new_rank)
                messages.error(request, " update success")

            else:
                record_return, created = models.Programranks.objects.get_or_create(title=program, hid=famID,
                                                                                   rank=new_rank)
                messages.error(request, "new input success")

                if not created:
                    messages.error(request, "Error: the record already exists")
                # new_content = Programranks(title=program, hid=famID, rank=new_rank)
                # new_content.save()
        if 'talkSubmit' in request.POST:
            input_num = request.POST.get('mRank')
            input_genre = request.POST.get('genre')
        with connection.cursor() as cursor:
            cursor.execute(
                """
       select top 5 *
    from
    (select  title , avgRank
    from
         (  select TS.title, avg(rank + 0.0) avgRank
          from ProgramRanks PR
                   inner join
               (select T.title
                from (select ProgramRanks.title, count(ProgramRanks.title) numRanks
                      from ProgramRanks
                               inner join
                           Programs P on ProgramRanks.title = P.title
                      where genre = %s--input
                      group by ProgramRanks.title) T
                where T.numRanks >= %s) TS--input
               on PR.title = TS.title
          group by TS.title) D
    union
        (select title,0 avgRank
        from
            (select title
            from Programs
            where genre = %s) C
        where C.title not in
           ( select T.title
                    from (select ProgramRanks.title, count(ProgramRanks.title) numRanks
                          from ProgramRanks
                                   inner join
                               Programs P on ProgramRanks.title = P.title
                          where genre = %s--input
                          group by ProgramRanks.title) T
                    where T.numRanks >= %s))--input
    ) RR
    order by avgRank desc, title
                                        """, [input_genre, input_num, input_genre, input_genre, input_num])

            sql_res5 = dictfetchall(cursor)
    # genres = []
    # for item in models.Programs.objects.values('genre').distinct():
    #     if Programs.objects.filter(genre=item['genre']).count() >= 5:
    #         genres.append(item['genre'])
    genres = models.Programs.objects.values_list('genre', flat=True).annotate(count=Count('genre')).filter(count__gte=5).distinct()
    return render(request, 'Ranks.html', {'titles': titles,
                                          'families': families,
                                          'genres': genres,
                                          'sql_res5': sql_res5})


def query(request):
    with connection.cursor() as cursor:
        cursor.execute(
            """
-- query 1
select  distinct A.genre,  Programs.title ,  MaxDuration as Duration
from
    ((
    (
       (select distinct  genre
       from Programs
       where genre like 'A%') as A
            inner join
       (select  genre, max(duration) MaxDuration
        from Programs
        group by genre) as maximum
            on  A.genre=maximum.genre)
              inner join  Programs
              on MaxDuration=Programs.duration and A.genre=Programs.genre)
                    inner join
       (select title,noKids.hid
        from
          (select hid
            from Households
            where ChildrenNum=0 )as noKids
                inner join
            RecordReturns
                on noKids.hID=RecordReturns.hID) as A2
                on Programs.title=A2.title)  inner join  Programs  p1
              on MaxDuration=p1.duration and A.genre=p1.genre and p1.title=
          (SELECT MIN(title)
          FROM Programs
          WHERE genre = p1.genre and duration=maximum.MaxDuration)
order by genre
                                """)
        sql_res1 = dictfetchall(cursor)
    # input_text = sys.maxsize
    # if request.method == 'POST' and request.POST:
    #     input_text = request.POST.get('numOfMovies', 0)
    with connection.cursor() as cursor:
        cursor.execute(
            """select title , format(round(CAST(AVG(rank +0.0) AS float) ,2),'0.00') as Average_Rank
from ProgramRanks
where title in
      (select p1.title
       from
         (select hID, title
          from RecordReturns
          union
          select hID, title
          from RecordOrders) p1
            inner JOIN
          ProgramRanks PR
        on Pr.title=p1.title and p1.hID=PR.hID
group by p1.title
having count(pr.rank)>=3)
group by title
order by Average_Rank desc ,title     """)
        sql_res2 = dictfetchall(cursor)
    with connection.cursor() as cursor:
        cursor.execute(
            """select title
from
    (select Rich.title,numFamily,numOf8AndAbove
    from
    (select More10.title, count(hid) numFamily
    from
    (select title
    from RecordReturns
    group by title
    having(count (distinct hid))>=10) More10
        inner join RecordReturns  RR
    on more10.title=RR.title
    group by More10.title) moreThanTen
        inner join
    (SELECT title, count(hid) numOf8AndAbove
    FROM (
    SELECT title, H.hid
    FROM Households H
    INNER JOIN RecordReturns RR on H.hID = RR.hID
    WHERE H.hid IN (SELECT hid FROM Households WHERE netWorth >= 8)
         ) T
    GROUP BY title) Rich on Rich.title=moreThanTen.title) X
    where numOf8AndAbove>0.5*numFamily and
    title not in
    (select title
    from ProgramRanks
    where rank<2)
order by title
                                """)
        sql_res3 = dictfetchall(cursor)

    return render(request, 'queryResult.html', {'sql_res1': sql_res1,
                                                'sql_res2': sql_res2,
                                                'sql_res3': sql_res3})
