from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('index', views.index, name='index'),
    path('add_content', views.management, name='management'),
    path('Ranks', views.ranks, name='ranks'),

    # path('add_content', views.returns, name='return'),
    # path('add_content', views.query4, name='query4'),
    path('queryResult', views.query, name='queryResult'),

]
