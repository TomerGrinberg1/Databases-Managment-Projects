import sys

from django.shortcuts import render
from .models import Movies
from django.db import connection

from datetime import datetime


def add_content(request):
    if request.method == 'POST' and request.POST:
        new_title = request.POST["movie-title"]
        date = request.POST["release-date"]
        genre = request.POST["genre"]
        rating = request.POST["rating"]
        gross = request.POST["gross"]

        new_content = Movies(movietitle=new_title,
                             releasedate=date,
                             genre=genre,
                             rating=rating,
                             gross=gross)
        new_content.save()
    return render(request, 'add_content.html')


def dictfetchall(cursor):
    # Return all rows from a cursor as a dict
    columns = [col[0] for col in cursor.description]
    return [dict(zip(columns, row)) for row in cursor.fetchall()]


def index(request):
    return render(request, 'index.html')


def query(request):
    with connection.cursor() as cursor:
        cursor.execute(
            """select pp1.genre as genre, pp1.movieTitle as movieTitle, pp1.maxGross as maxGross, pp1.longestTitle as longestTitle,
               COALESCE(pp2.moreThanOneYearCount,0) as moreThanOneYearCount
        from (
            select p1.genre,p1.movieTitle, p1.maxGross, p2.movieTitle as longestTitle
            from
        (select M.genre ,movieTitle, maxGross
        from
                Movies M
            INNER JOIN
                (select genre, max(gross) as maxGross
                from Movies
                group by genre) as topGross
            on M.genre = topGross.genre
            and M.gross = topGross.maxGross) as p1
            INNER JOIN
            (SELECT m.genre, m.movieTitle, len(movieTitle) as longestNameLen
        FROM Movies m
        INNER JOIN (
          SELECT genre, MAX(LEN(movieTitle)) AS longestNameLen
          FROM Movies
          GROUP BY genre
        ) g ON m.genre = g.genre AND LEN(m.movieTitle) = g.longestNameLen AND m.movieTitle = (
          SELECT MIN(movieTitle)
          FROM Movies
          WHERE genre = m.genre AND LEN(movieTitle) = g.longestNameLen
        )) as p2
        on p1.genre = p2.genre ) as pp1
        left outer join
            (
                select genre, count(t.genre) as moreThanOneYearCount
        from
            (select genre
        from Movies
        group by genre,YEAR(releaseDate)
        having count(YEAR(releaseDate)) > 1) as t
        group by t.genre
            ) as pp2
        on pp1.genre = pp2.genre
        order by pp1.genre
                                """)
        sql_res1 = dictfetchall(cursor)
    input_text = sys.maxsize
    if request.method == 'POST' and request.POST:
        input_text = request.POST.get('numOfMovies', 0)
    with connection.cursor() as cursor:
        cursor.execute(
            """select distinct(pp1.actor) as actor, pp1.movie as movie
        from
        (select actor, movie, releaseDate
        from Movies
            INNER JOIN ActorsInMovies AIM
                on Movies.movieTitle = AIM.movie) as pp1
            INNER JOIN
        (select p1.actor, p1.minRelease
        from (
            select actor,MIN(releaseDate) as minRelease
        from  Movies
            INNER JOIN ActorsInMovies AIM
                on Movies.movieTitle = AIM.movie
        group by actor
             ) as p1
        INNER JOIN
            (
                select actor, count(movie) as movieCount
        from Movies
            INNER JOIN ActorsInMovies AIM
                on Movies.movieTitle = AIM.movie
        group by actor
        having count(DISTINCT (movie)) >  %s
            ) as p2
        on p1.actor = p2.actor) as pp2
        on pp1.actor = pp2.actor and pp1.releaseDate = pp2.minRelease
                                """, [input_text])
        sql_res2 = dictfetchall(cursor)
    with connection.cursor() as cursor:
        cursor.execute(
            """select top 5 movie, count(ppp1.actor) as childOnlyActors
        from (select distinct ActorsInMovies.movie, actorsInMovies.actor
        from ActorsInMovies
            INNER JOIN
            (select actor
        from (select actor
        from Movies
            INNER JOIN ActorsInMovies AIM
                on Movies.movieTitle = AIM.movie
        where rating = 'G'
        group by actor
        having count(distinct(movie)) >= 4) as p1
            except
        (select actor
        from Movies
            INNER JOIN ActorsInMovies AIM
                on Movies.movieTitle = AIM.movie
        where rating = 'R'
        group by actor
        having count(distinct(movie)) > 0 )) as pp1
        on ActorsInMovies.actor = pp1.actor) as ppp1
        group by movie
        order by count(ppp1.actor) desc, movie
                                """)
        sql_res3 = dictfetchall(cursor)

    return render(request, 'queryResult.html', {'sql_res1': sql_res1,
                                                'sql_res2': sql_res2,
                                                'sql_res3': sql_res3})
